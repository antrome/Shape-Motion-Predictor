version = '0.67.6'
short_version = version
full_version = version
