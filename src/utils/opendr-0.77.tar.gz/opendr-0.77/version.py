version = '0.77'
short_version = version
full_version = version
