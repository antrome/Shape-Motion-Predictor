version = '0.78'
short_version = version
full_version = version
